import express from "express";
import fetch from "node-fetch";

const app = express();
app.use(express.json());

// Map Maistro result into the two fields the UI expects.
// We defensively read several common shapes just in case.
function pick(field, data) {
  return (
    data?.[field] ??
    data?.output?.[field] ??
    data?.result?.[field] ??
    data?.data?.[field] ??
    null
  );
}

app.post("/api/improve", async (req, res) => {
  const { inputMessage, intendedTone, communicationContext, personaType } = req.body;

  try {
    // IMPORTANT: Use the *API* hostname + /v1/<instance>/maistro
    const url = "https://stagingapi.neuralseek.com/v1/Talhas_Instance/maistro";
    const apiKey = process.env.NEURALSEEK_API_KEY;

    const body = {
      agent: "EmailTone_Expert1",
      params: [
        { name: "inputMessage", value: inputMessage ?? "" },
        { name: "intendedTone", value: intendedTone ?? "" },
        { name: "communicationContext", value: communicationContext ?? "" },
        { name: "personaType", value: personaType ?? "" }
      ]
    };

    const response = await fetch(url, {
      method: "POST",
      headers: {
        accept: "application/json",
        apikey: apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });

    // Log non-200 payloads for easy debug in Replit console
    if (!response.ok) {
      const errText = await response.text();
      console.error("NeuralSeek error:", response.status, errText);
      return res.status(response.status).json({
        error: "NeuralSeek API error",
        status: response.status,
        details: errText
      });
    }

    const data = await response.json();

    // NeuralSeek Maistro often returns { answer: "Rephrased... \nExplanation: ..." }
    let rephrasedMessage = "";
    let explanation = "";

    if (typeof data.answer === "string") {
      // Split by "Explanation:" if present
      const parts = data.answer.split(/Explanation:/i);
      rephrasedMessage = parts[0].replace(/^Rephrased Message:/i, "").trim();
      explanation = parts[1] ? parts[1].trim() : "No explanation provided.";
    } else {
      rephrasedMessage = JSON.stringify(data);
      explanation = "Raw response shown because parsing failed.";
    }

    return res.json({ rephrasedMessage, explanation });
  } catch (err) {
    console.error("Server exception:", err);
    return res.status(500).json({ error: err.message || "Server error" });
  }
});

app.listen(3001, "0.0.0.0", () => {
  console.log("✅ Backend running on port 3001");
});