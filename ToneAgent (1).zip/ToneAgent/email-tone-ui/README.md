# Email Tone UI

## GitHub Pages (optional):
- If deploying under a subpath, set `base: '/REPO_NAME/'` in vite.config.js when publishing to a subpath.

## Local run:
- npm install
- npm run dev  (http://localhost:3000)

## Production build:
- npm run build
- npm run preview  (serves dist on port 3000)

## Netlify deploy:
- Build command: npm run build
- Publish directory: dist
- Include `public/_redirects`

## GitHub Pages (optional):
- If deploying under a subpath, set `base` in vite.config.js (e.g., base: '/REPO_NAME/').
- Use a tool like `gh-pages` to publish `dist`.
