import React, { useMemo, useState } from "react";

/**
 * In-browser mock so the app works without a backend or any paid service.
 * Returns BOTH a rephrasedMessage and an explanation.
 */
function mockImproveEmail({ inputMessage, intendedTone, communicationContext, personaType }) {
  const tone = (intendedTone || "neutral").toLowerCase();
  const ctx  = communicationContext || "";
  const persona = personaType || "";

  // Very small "style" helpers
  const soften = (txt) =>
    txt
      .replace(/\bunacceptable\b/gi, "not ideal")
      .replace(/\bimmediately\b/gi, "as soon as possible")
      .replace(/\bthis is my third time\b/gi, "I've followed up a few times");

  const addEmpathy =
    "I understand the urgency here and appreciate your help. ";
  const addProfessional =
    "Thank you for your attention to this matter. ";
  const addDirect =
    "Please see the request below. ";
  const addPolite =
    "If possible, could you please review the following? ";
  const addAcademic =
    "In accordance with formal guidance, ";

  let prefix = "";
  if (tone.includes("empat")) prefix = addEmpathy;
  else if (tone.includes("professional")) prefix = addProfessional;
  else if (tone.includes("direct")) prefix = addDirect;
  else if (tone.includes("polite")) prefix = addPolite;
  else if (tone.includes("academic")) prefix = addAcademic;

  const base = soften((inputMessage || "").trim());
  const cap = base ? base[0].toUpperCase() + base.slice(1) : base;
  const contextLine = ctx ? `[Context: ${ctx}] ` : "";
  const personaLine = persona ? `[Persona: ${persona}] ` : "";

  const rephrasedMessage = `${contextLine}${personaLine}${prefix}${cap}`.trim();

  const explanation = `The message was rephrased to reflect a ${intendedTone} tone suitable for the ${personaType || "selected"} persona within the context of ${communicationContext || "the chosen setting"}. Phrasing was softened, urgency acknowledged, and gratitude added to improve collaboration and maintain professionalism.`;

  return { rephrasedMessage, explanation };
}

// Combobox component that allows both selection and custom input
const Combobox = ({ value, onChange, options, placeholder, label }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);

  const filteredOptions = options.filter(option =>
    option.toLowerCase().includes(value.toLowerCase())
  );

  const handleInputChange = (e) => {
    onChange(e.target.value);
    setIsOpen(true);
    setHighlightedIndex(-1);
  };

  const handleOptionClick = (option) => {
    onChange(option);
    setIsOpen(false);
    setHighlightedIndex(-1);
  };

  const handleKeyDown = (e) => {
    if (!isOpen) {
      if (e.key === 'ArrowDown') {
        setIsOpen(true);
        setHighlightedIndex(0);
        e.preventDefault();
      }
      return;
    }

    switch (e.key) {
      case 'ArrowDown':
        setHighlightedIndex(prev => 
          prev < filteredOptions.length - 1 ? prev + 1 : prev
        );
        e.preventDefault();
        break;
      case 'ArrowUp':
        setHighlightedIndex(prev => prev > 0 ? prev - 1 : -1);
        e.preventDefault();
        break;
      case 'Enter':
        if (highlightedIndex >= 0) {
          handleOptionClick(filteredOptions[highlightedIndex]);
        }
        e.preventDefault();
        break;
      case 'Escape':
        setIsOpen(false);
        setHighlightedIndex(-1);
        break;
    }
  };

  return (
    <div className="form-group">
      <label>{label}</label>
      <div className="combobox-container">
        <input
          className="combobox-input"
          value={value}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsOpen(true)}
          onBlur={() => setTimeout(() => setIsOpen(false), 200)}
          placeholder={placeholder}
        />
        <span className="dropdown-arrow">▼</span>
        {isOpen && filteredOptions.length > 0 && (
          <div className="combobox-dropdown">
            {filteredOptions.map((option, index) => (
              <div
                key={option}
                className={`combobox-option ${index === highlightedIndex ? 'highlighted' : ''}`}
                onMouseDown={() => handleOptionClick(option)}
                onMouseEnter={() => setHighlightedIndex(index)}
              >
                {option}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default function App() {
  const [inputMessage, setInputMessage] = useState("");
  const [intendedTone, setIntendedTone] = useState("empathetic");
  const [communicationContext, setCommunicationContext] = useState("internal team message");
  const [personaType, setPersonaType] = useState("internal employee");
  const [isLoading, setIsLoading] = useState(false);
  const [rephrasedMessage, setRephrasedMessage] = useState("");
  const [explanation, setExplanation] = useState("");

  const handleLoadExample = () => {
    setInputMessage("This is my third time asking for the finalized onboarding documents. We have a new hire starting tomorrow, and this delay is completely unacceptable. I expected these documents to be ready two days ago. Please finalize and send them immediately.");
    setIntendedTone("empathetic");
    setCommunicationContext("internal team message");
    setPersonaType("internal employee");
  };

  const toneOptions = [
    'empathetic',
    'professional',
    'direct',
    'academic',
    'polite',
    'neutral'
  ];

  const contextOptions = [
    'internal team message',
    'customer service reply',
    'academic email',
    'escalation response',
    'external partner',
    'executive update'
  ];

  const personaOptions = [
    'student',
    'internal employee',
    'academic researcher',
    'customer service representative',
    'startup founder'
  ];

  const handleImproveMessage = async () => {
    if (!inputMessage.trim()) return;

    setIsLoading(true);
    
    try {
      const res = await fetch("/api/improve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ inputMessage, intendedTone, communicationContext, personaType })
      });
      const data = await res.json();
      setRephrasedMessage(data.rephrasedMessage);
      setExplanation(data.explanation);
    } catch (error) {
      console.error("Error improving message:", error);
      setRephrasedMessage("Error occurred while improving the message.");
      setExplanation("Please try again later.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="email-tone-agent">
      <div className="header">
        <h1>Email Tone Agent</h1>
        <p>Transform your emails with the perfect tone, context, and persona</p>
      </div>
      
      <div className="content">
        <div className="form-section">
          <div className="form-grid">
            <div className="form-group input-message">
              <label htmlFor="inputMessage">Input Message</label>
              <textarea
                id="inputMessage"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Enter your email message here..."
              />
              <button
                type="button"
                onClick={handleLoadExample}
                style={{
                  marginTop: '8px',
                  padding: '8px 16px',
                  backgroundColor: '#667eea',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '0.9rem'
                }}
              >
                Load Example
              </button>
            </div>
            
            <Combobox
              value={intendedTone}
              onChange={setIntendedTone}
              options={toneOptions}
              label="Intended Tone"
              placeholder="Select or type a tone..."
            />
            
            <Combobox
              value={communicationContext}
              onChange={setCommunicationContext}
              options={contextOptions}
              label="Communication Context"
              placeholder="Select or type a context..."
            />
            
            <div className="form-group" style={{gridColumn: '1 / -1'}}>
              <Combobox
                value={personaType}
                onChange={setPersonaType}
                options={personaOptions}
                label="Persona Type"
                placeholder="Select or type a persona..."
              />
            </div>
          </div>
          
          <button
            className="improve-button"
            onClick={handleImproveMessage}
            disabled={!inputMessage.trim() || isLoading}
          >
            {isLoading ? 'Improving Message...' : 'Improve Message'}
          </button>
        </div>

        {isLoading && (
          <div className="loading">
            <div className="spinner"></div>
            Processing your message...
          </div>
        )}

        {(rephrasedMessage || explanation) && !isLoading && (
          <div className="results-section">
            <div className="result-grid">
              <div className="result-card">
                <h3>Explanation</h3>
                <div className="explanation">
                  {explanation}
                </div>
              </div>
              
              <div className="result-card">
                <h3>Rephrased Message</h3>
                <div className="rephrased-message">
                  {rephrasedMessage}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
