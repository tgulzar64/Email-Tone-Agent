export default {
  server: {
    host: "0.0.0.0",
    port: 3000,
    allowedHosts: ["all", "96b3137f-6f8d-4b56-91e7-4ee8b5bf5034-00-2prbuk2tekvy6.kirk.replit.dev"],
    proxy: {
      "/api": {
        target: "http://127.0.0.1:3001",
        changeOrigin: true
      }
    }
  }
};