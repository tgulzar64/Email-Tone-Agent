# Email Tone Agent

## Overview

The Email Tone Agent is a React-based web application designed to transform email messages by adjusting their tone, context, and persona. Built with Vite for fast development and modern tooling, this single-page application provides users with intelligent email transformation capabilities through sophisticated in-browser processing without requiring external APIs. The app features a clean, responsive interface that allows users to input messages and receive professionally refined versions with detailed explanations of the changes made.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 19**: Modern React application using the latest version with functional components and hooks
- **Vite**: Fast build tool and development server configured for React, providing hot module replacement and optimized builds
- **Single Page Application**: All functionality contained within a single React component structure
- **Component-based Design**: Modular architecture separating concerns between UI components and business logic

### UI/UX Design Patterns
- **Responsive Design**: CSS-based responsive layout that adapts to different screen sizes without external UI frameworks
- **Custom Styling**: Pure CSS implementation avoiding external UI libraries for minimal bundle size
- **Gradient Headers**: Modern visual design with CSS gradients for professional appearance
- **Form-based Interaction**: Multi-input form pattern with dropdowns and text areas for user input

### Data Processing Architecture
- **Client-side Transformation**: All email processing happens in the browser using sophisticated JavaScript algorithms
- **Mock AI Logic**: Intelligent transformation rules simulating AI-powered text processing without external API dependencies
- **Rule-based System**: Transformation engine using predefined rules for different tones, contexts, and personas
- **Real-time Processing**: Immediate transformation and explanation generation upon user interaction

### Transformation Engine Design
- **Tone-specific Rules**: Separate transformation logic for empathetic, professional, direct, academic, polite, and neutral tones
- **Context Awareness**: Different processing approaches for internal team messages, customer service replies, academic emails, escalation responses, external partner communications, and executive updates
- **Persona Adaptation**: Customized output based on user roles including student, internal employee, academic researcher, customer service representative, and startup founder
- **Explanation Generation**: Detailed rationale provided for all transformations to educate users on communication improvements

## External Dependencies

### Core Dependencies
- **React 19.1.1**: Frontend library for building the user interface with modern React features
- **React-DOM 19.1.1**: DOM rendering library for React components
- **Vite 7.1.3**: Build tool and development server for fast development experience
- **@vitejs/plugin-react 5.0.1**: Vite plugin enabling React support with Fast Refresh

### Development Infrastructure
- **Node.js**: Runtime environment required for package management and build processes
- **npm**: Package manager for dependency installation and script execution
- **Modern Browser**: Client-side application requiring ES6+ compatible browser environment

### Notable Architecture Decisions
- **No External APIs**: Deliberately designed to work offline with sophisticated client-side processing
- **No Database**: Stateless application with no persistent data storage requirements
- **No Authentication**: Public-facing tool requiring no user accounts or sessions
- **No External UI Libraries**: Custom CSS implementation for full control over styling and minimal dependencies